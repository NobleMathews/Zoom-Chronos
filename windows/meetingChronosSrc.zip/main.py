import sys
from notifypy import Notify
from datetime import datetime, timedelta
from threading import Timer
from datetime import date
import time
import schedule
import webbrowser
import csv
import wx
import wx.adv
import os
import os.path
import locale
import bisect
import threading
import configobj


# rewrite in future for class structure for managing jobs


# noinspection PyBroadException
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    base_path = os.path.abspath(".")
    if hasattr(sys, "_MEIPASS"):
        try:
            # PyInstaller creates a temp folder and stores path in MEIPASS
            base_path = sys._MEIPASS
        except Exception:
            base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


def stop_sounds(sound_object):
    sound_object.Stop()


my_dir = os.path.dirname(os.path.abspath(__file__))
DATE_CHECK = True
AUTO_EXIT = -1
TRAY_TOOLTIP = "MeetingChronos"
TRAY_ICON = "bypass/bell.png"
TRAY_ICON = TRAY_ICON if os.path.exists(TRAY_ICON) else resource_path("bell.png")
ALERT_AUDIO = "bypass/alarm.wav"
ALERT_AUDIO = ALERT_AUDIO if os.path.exists(ALERT_AUDIO) else resource_path("alarm.wav")
# INI_FILE = resource_path("config.ini")
INI_FILE = os.path.join(my_dir, "config.ini")
# ALARM_DATA = os.path.join(my_dir, "bypass/data.csv")
# ALARM_DATA = ALARM_DATA if os.path.exists(ALARM_DATA) else os.path.join(my_dir, "data.csv")
ALARM_DATA = os.path.join(my_dir, "data.csv")
notification = Notify()
t_format = '%H:%M'
ALARM_SEC = 2.0
# not zero
time_before = 5
daily_alarm = []
daily_enabled = {}
cease_continuous_run = threading.Event()


def str2bool(v):
    return str(v).lower() in ("yes", "true", "t", "1")


def change_global(str_global, val_global):
    global DATE_CHECK, AUTO_EXIT, ALARM_SEC, time_before
    if str_global is "DATE_CHECK":
        DATE_CHECK = str2bool(val_global)
    elif str_global is "AUTO_EXIT":
        AUTO_EXIT = int(val_global)
    elif str_global is "ALARM_SEC":
        ALARM_SEC = float(val_global)
    elif str_global is "time_before":
        time_before = int(val_global)


# noinspection PyPep8Naming,PyAttributeOutsideInit,PyUnusedLocal,PyUnresolvedReferences
class PreferencesDialog(wx.Dialog):

    def __init__(self):
        wx.Dialog.__init__(self, None, wx.ID_ANY, 'Preferences', size=(550, 300))
        self.createWidgets()

    def createWidgets(self):
        lblSizer = wx.BoxSizer(wx.VERTICAL)
        valueSizer = wx.BoxSizer(wx.VERTICAL)
        btnSizer = wx.StdDialogButtonSizer()
        colSizer = wx.BoxSizer(wx.HORIZONTAL)
        mainSizer = wx.BoxSizer(wx.VERTICAL)

        iniFile = INI_FILE
        self.config = configobj.ConfigObj(iniFile)

        labels = self.config["Labels"]
        values = self.config["Values"]
        self.widgetNames = values
        font = wx.Font(12, wx.SWISS, wx.NORMAL, wx.BOLD)

        for key in labels:
            value = labels[key]
            lbl = wx.StaticText(self, label=value)
            lbl.SetFont(font)
            lblSizer.Add(lbl, 0, wx.ALL, 5)

        for key in values:
            print(key)
            value = values[key]
            if isinstance(value, list):
                # default = value[0]
                choices = value[1:]
                cbo = wx.ComboBox(self, value=value[0],
                                  size=wx.DefaultSize, choices=choices,
                                  style=wx.CB_DROPDOWN | wx.CB_READONLY,
                                  name=key)
                valueSizer.Add(cbo, 0, wx.ALL, 5)
            else:
                txt = wx.TextCtrl(self, value=value, name=key)
                valueSizer.Add(txt, 0, wx.ALL | wx.EXPAND, 5)

        saveBtn = wx.Button(self, wx.ID_OK, label="Save")
        saveBtn.Bind(wx.EVT_BUTTON, self.onSave)
        btnSizer.AddButton(saveBtn)

        cancelBtn = wx.Button(self, wx.ID_CANCEL)
        btnSizer.AddButton(cancelBtn)
        btnSizer.Realize()

        colSizer.Add(lblSizer)
        colSizer.Add(valueSizer, 1, wx.EXPAND)
        mainSizer.Add(colSizer, 0, wx.EXPAND)
        mainSizer.Add(btnSizer, 0, wx.ALL | wx.ALIGN_RIGHT, 5)
        self.SetSizer(mainSizer)

    def onSave(self, event):
        """
        Saves values to disk
        """
        for name in self.widgetNames:
            widget = wx.FindWindowByName(name)
            if isinstance(widget, wx.ComboBox):
                selection = widget.GetValue()
                choices = widget.GetItems()
                choices.insert(0, selection)
                self.widgetNames[name] = choices
                change_global(name, selection)
            else:
                value = widget.GetValue()
                change_global(name, value)
                self.widgetNames[name] = value
        self.config.write()
        self.EndModal(0)


class Zoom:
    def __init__(self, meeting_link):
        url = ""
        if meeting_link.find("https://") != -1 \
                and meeting_link.find("zoom.us") != -1 \
                and meeting_link.find("/j/") != -1:
            url = "zoommtg://zoom.us/join?zc=0&stype=100&confno=" + meeting_link[meeting_link.find("/j/") + 3:]

        elif meeting_link.isdecimal():
            url = "zoommtg://zoom.us/join?zc=0&stype=100&confno=" + meeting_link

        if url.find("?pwd=") != 1:
            url = url.replace("?pwd=", "&pwd=")
        # print(url)
        # [TODO] currently bypassing url
        self.meeting_link = meeting_link
        # if url != "":
        # Procesmeeting_link.Start("open", url)
        # else return -1

    @classmethod
    def from_id_pass(cls, meeting_id, meeting_pass):
        meeting_link = "zoommtg://zoom.us/join?zc=0&stype=100&confno=" + meeting_id
        if meeting_pass.len > 0:
            meeting_link += "&pwd=" + meeting_pass
        return cls(meeting_link)

    def run(self):
        try:
            print(self.meeting_link)
            sound = wx.adv.Sound(ALERT_AUDIO)
            sound.Play(wx.adv.SOUND_ASYNC)
            t = Timer(ALARM_SEC, stop_sounds, args=[sound])
            t.start()
            return webbrowser.get('C:/Program Files/Google/Chrome/Application/chrome.exe %s').open(self.meeting_link)
        except webbrowser.Error as e:
            print(e)
            pass


# noinspection PyMethodMayBeStatic
class TaskBarIcon(wx.adv.TaskBarIcon):
    def __init__(self):
        super(TaskBarIcon, self).__init__()
        self.set_icon(TRAY_ICON)
        self.Bind(wx.adv.EVT_TASKBAR_LEFT_DOWN, self.on_left_down)

    @staticmethod
    def toggle_menuitem(hour):
        if daily_enabled[str(hour)]:
            daily_enabled[str(hour)] = False
            clear_job(str(hour))
        else:
            daily_enabled[str(hour)] = True
            with open(ALARM_DATA, encoding='utf-8-sig') as csvfile:
                data = csv.DictReader(csvfile)
                row = ""
                for i in data:
                    if i['start'] == hour:
                        row = i
                try:
                    schedule.every().day.at(str(alert_time(str(row['start']) + ":00"))).do(job_once, row["link"],
                                                                                           row['id'], row["pass"],
                                                                                           row["course"]).tag(
                        'daily-tasks', str(row['start']))
                except AttributeError as error:
                    print("data_error ", error)

    def CreatePopupMenu(self):
        global daily_alarm, daily_enabled
        menu = wx.Menu()
        create_menu_item(menu, 'Manual Launch', self.launch_meet)
        menu.AppendSeparator()
        create_menu_item(menu, 'Exit', self.on_exit)
        create_menu_item(menu, 'Settings', self.edit_settings)
        create_menu_item(menu, 'Reload Data', update_data)
        for item in daily_alarm:
            hour = int(item['start'])
            menu.AppendCheckItem(hour, item['start'] + ":00 " + item['course'])
            menu.Check(hour, daily_enabled[str(hour)])
            menu.Bind(wx.EVT_MENU, lambda event, opt=hour: self.toggle_menuitem(opt), id=hour)

        return menu

    def edit_settings(self, event):
        print(event)
        dlg = PreferencesDialog()
        dlg.ShowModal()
        dlg.Destroy()

    def set_icon(self, icon_path):
        icon = wx.Icon(icon_path)
        self.SetIcon(icon, TRAY_TOOLTIP)

    def on_left_down(self, event):
        print(event)
        os.startfile(ALARM_DATA)

    def launch_meet(self, event):
        print(event)
        hour = datetime.now().hour
        minute = datetime.now().minute
        minute_factor = minute * (1/60)
        target = take_closest_slot(daily_alarm, hour, minute_factor)
        # print(target['course'])
        job_once(target['link'], target['id'], target['pass'], target['course'])

    def on_exit(self, event):
        print(event)
        cease_continuous_run.set()
        wx.CallAfter(self.Destroy)


def take_closest_slot(my_list, my_number, minute_factor):
    hours = [int(d['start']) for d in my_list]
    my_hour = my_number + minute_factor

    idx = bisect.bisect(hours, my_hour)
    if 0 < idx < len(my_list):
        if (my_number - my_hour)*60 <= time_before:
            if idx != len(my_list)-1:
                idx = idx + 1
        return my_list[idx - 1]
    elif my_number >= hours[-1]:
        return my_list[-1]
    else:
        return my_list[0]


def alert_time(string_time):
    return datetime.strftime((datetime.strptime(string_time, t_format) - timedelta(minutes=time_before)), t_format)


def class_time(class_name):
    notification.title = "Time for your class !!"
    notification.application_name = TRAY_TOOLTIP
    notification.message = class_name
    notification.icon = TRAY_ICON
    # notification.audio = ALERT_AUDIO
    notification.send()


def create_menu_item(menu, label, func):
    item = wx.MenuItem(menu, -1, label)
    menu.Bind(wx.EVT_MENU, func, id=item.GetId())
    menu.Append(item)
    return item


def only_enabled(row):
    day = datetime.now().strftime('%a').lower()
    return 'no' in row['disabled'] and day in row['day']


# run beginning on day and when file updated
# noinspection PyUnusedLocal
def update_data(*args):
    schedule.clear('daily-tasks')
    global daily_alarm, daily_enabled
    hour = datetime.now().hour
    daily_alarm = []
    daily_enabled = {}
    holiday_list = []
    max_hour = 0
    with open(ALARM_DATA, encoding='utf-8-sig') as csv_file:
        data = csv.DictReader(csv_file)
        for row in filter(only_enabled, data):
            daily_alarm.append(row)
            daily_enabled[row['start']] = True
            if row['holidays']:
                holiday_list.append(row['holidays'])
            # method = "GET"
            # getattr(handler.request, method).add()
            if int(row['start']) > max_hour:
                max_hour = int(row['start'])
            schedule.every().day.at(str(alert_time(str(row['start']) + ":00"))).do(job_once, row["link"], row['id'],
                                                                                   row["pass"], row["course"]).tag(
                'daily-tasks', str(row['start']))
    if DATE_CHECK:
        check_holiday(holiday_list)
    schedule.every().hour.do(end_time, hour=hour, max_hour=max_hour)
    # print(daily_alarm)
    # print(schedule.jobs)
    print(daily_enabled)


def job_once(link, id_meet, pass_meet, course="class_time"):
    class_time(course)
    if link:
        alarm_action = Zoom(link)
        alarm_action.run()
    elif id_meet and pass_meet:
        alarm_action = Zoom.from_id_pass(id_meet, pass_meet)
        alarm_action.run()
    return schedule.CancelJob


def clear_job(tag):
    schedule.clear(tag)


def run_continuously(interval=1):
    global cease_continuous_run

    class ScheduleThread(threading.Thread):
        @classmethod
        def run(cls):
            while not cease_continuous_run.is_set():
                schedule.run_pending()
                time.sleep(interval)

    continuous_thread = ScheduleThread()
    continuous_thread.start()
    return cease_continuous_run


def check_holiday(holiday_list):
    today = date.today().strftime('%d-%m-%Y')
    if today in holiday_list:
        exit()


def end_time(hour, max_hour):
    option = AUTO_EXIT
    if option not in [0, -1]:
        exit_time = AUTO_EXIT
    elif option is -1:
        exit_time = max_hour
    else:
        return
    if hour > exit_time:
        exit()


def main():
    app = wx.App()
    app.locale = wx.Locale(wx.LANGUAGE_ENGLISH)
    locale.setlocale(locale.LC_ALL, 'en_US')
    update_data()
    schedule.every().day.do(update_data).tag('daily-task')
    run_continuously()
    TaskBarIcon()
    app.MainLoop()


if __name__ == '__main__':
    main()
